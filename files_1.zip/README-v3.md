# Fast Data for AI — Engineering do Brasil

## Arquivos

| Arquivo | Descrição | Audiência |
|---|---|---|
| `index.html` | Hub — página inicial com cards | Todos |
| `onepage.html` | One-page comercial completa (AI-first) | C-level, decisores |
| `comparativo.html` | 3 arquiteturas + AI-readiness | Gestão, técnico |
| `simulador.html` | Demo interativa com chat | Reuniões ao vivo |
| `arquitetura.html` | 6 camadas + AI Journey | CTOs, arquitetos |
| `comercial.html` | Guia comercial completo | Time de vendas |
| `battlecard.html` | Battle card (referência rápida) | Vendedores em campo |

## Deploy

```powershell
cd C:\deploy\fast-data
powershell -ExecutionPolicy Bypass -File .\deploy.ps1
```

## URLs

- Hub: https://fernando-teves.github.io/fast-data/
- One-page: https://fernando-teves.github.io/fast-data/onepage.html
- Comparativo: https://fernando-teves.github.io/fast-data/comparativo.html
- Simulador: https://fernando-teves.github.io/fast-data/simulador.html
- Arquitetura: https://fernando-teves.github.io/fast-data/arquitetura.html
- Guia Comercial: https://fernando-teves.github.io/fast-data/comercial.html
- Battle Card: https://fernando-teves.github.io/fast-data/battlecard.html

## Versão

- **v3.0** — Maio 2026 | Narrativa AI-first
- Engineering do Brasil — The Digital Transformation Company
